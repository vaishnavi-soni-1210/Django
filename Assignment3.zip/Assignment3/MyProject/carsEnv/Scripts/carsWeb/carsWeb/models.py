from datetime import datetime
import pymysql
from django.db import models
from django.utils.html import mark_safe

class UserRegistration:
    def registerUser(fnm,lnm,email,mob):
        mess=None
        try:
            con=pymysql.connect(host='bme17yv2uewp4z5ou9c2-mysql.services.clever-cloud.com',user='upx7pvsovd5grndj',password='zFYKoGDMCiX3s5DZXAJY',database='bme17yv2uewp4z5ou9c2')
            curs=con.cursor()
            curs.execute("Insert into Customers(FirstName,LastName,EmailAddress,MobileNumber,IsActive) values ('%s','%s','%s','%s',%r)" %(fnm,lnm,email,mob,True))
            con.commit()
            con.close()
            mess='Successfully Added New Customer!'
        except ValueError as err:
            mess=err
        return mess
    
    def showAllCars(self):
        con=pymysql.connect(host='bme17yv2uewp4z5ou9c2-mysql.services.clever-cloud.com',user='upx7pvsovd5grndj',password='zFYKoGDMCiX3s5DZXAJY',database='bme17yv2uewp4z5ou9c2')
        curs=con.cursor()
        curs.execute("select * from AllCars") #view
        data=curs.fetchall()
        return data

class CarCompany(models.Model):
    CompanyName = models.CharField(max_length=100)
    IsActive = models.BooleanField()
    CreatedDate = models.DateTimeField()

    fields = ("CompanyName", "IsActive")

    class Meta:
        db_table = 'CarCompany'
        unique_together = ['CompanyName']

class Car(models.Model):

    CAR_TYPES = (
        ('Sedan', 'Sedan'),
        ('HatchBack', 'HatchBack'),
        ('Crossover', 'HatchBack'),
        ('Coupe', 'Coupe'),
        ('Convertible', 'Convertible'),
    )

    CarName = models.CharField(max_length=100)
    CarCompany = models.ForeignKey('CarCompany',on_delete=models.CASCADE)
    NoOfWheels = models.IntegerField()
    EngineCapacity = models.CharField(max_length=100)
    FuelType = models.CharField(max_length=100)
    Price = models.FloatField()
    CarType = models.CharField(max_length=100,choices = CAR_TYPES)    
    IsActive = models.BooleanField()
    CreatedDate = models.DateTimeField()
    CarImage = models.ImageField(upload_to='static/images', null=True, blank=True)

    @property
    def CarImage_Shortpreview(self):
        if self.CarImage:
            return mark_safe('<img src="{}" width="100" height="100" />'.format(self.CarImage.url))
        return ""

    @property
    def CarImage_Largepreview(self):
        if self.CarImage:
            return mark_safe('<img src="{}" width="300" height="300" />'.format(self.CarImage.url))
        return ""

    fields = ("CarName","CarImage","NoOfWheels","EngineCapacity","FuelType", "Price","CarType", "IsActive")

    class Meta:
        db_table = 'Cars'
        unique_together = ['CarName']
    

class Customer(models.Model):
    FirstName = models.CharField(max_length=100)
    LastName = models.CharField(max_length=100)
    EmailAddress = models.CharField(max_length=100)
    MobileNumber = models.CharField(max_length=100)
    IsActive = models.BooleanField()
    CreatedDate = models.DateTimeField()

    fields = ("FirstName","LastName","EmailAddress", "MobileNumber", "IsActive")

    class Meta:
        db_table = 'Customers'
        unique_together = ['EmailAddress','MobileNumber']
        
   
