from django.contrib import admin
from django import forms
# the module name is app_name.models
from carsWeb.models import CarCompany
from carsWeb.models import Car
from carsWeb.models import Customer

# Register your models to admin site, then you can add, edit, delete and search your models in Django admin site.
class CarsAdmin(admin.StackedInline):
    model = Car
    extra = 1

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == 'CarCompany':
            return CarCompanyChoiceField(queryset=CarCompany.objects.all())
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

class CarCompanyAdmin(admin.ModelAdmin):
    list_display = ('CompanyName', 'IsActive')
    inlines = [CarsAdmin]

class CarsAdmin(admin.ModelAdmin):
    list_display = ("CarName","CarImage_Shortpreview","NoOfWheels","EngineCapacity","FuelType", "Price","CarType", "IsActive")
    readonly_fields = ('CarImage_Shortpreview',)
    def CarImage_Shortpreview(self, obj):
        return obj.CarImage_Shortpreview

    CarImage_Shortpreview.short_description = 'Car Preview'
    CarImage_Shortpreview.allow_tags = True
    
    readonly_fields = ('CarImage_Largepreview',)
    def CarImage_Largepreview(self, obj):
        return obj.CarImage_Largepreview

    def __str__(self):
        return self.CarCompany.CompanyName

    CarImage_Largepreview.short_description = 'Car Preview'
    CarImage_Largepreview.allow_tags = True

class CustomersAdmin(admin.ModelAdmin):
    list_display = ('FirstName', 'LastName','EmailAddress','MobileNumber','IsActive')

class CarCompanyChoiceField(forms.ModelChoiceField):
     def label_from_instance(self, obj):
         return "CarCompany: {}".format(obj.CompanyName)
    

admin.site.register(CarCompany,CarCompanyAdmin)
admin.site.register(Car, CarsAdmin)
admin.site.register(Customer, CustomersAdmin)
