from flask import Flask
from flask_restful import Resource,Api
import pymysql

app=Flask(__name__)
api=Api(app)

class CarInfo(Resource):
    def get(self,modelName):
        con=pymysql.connect(host='bme17yv2uewp4z5ou9c2-mysql.services.clever-cloud.com',user='upx7pvsovd5grndj',password='zFYKoGDMCiX3s5DZXAJY',database='bme17yv2uewp4z5ou9c2')
        curs=con.cursor()
        curs.execute("select * from AllCars where CarName=%d" %modelName) #AllCars is a view
        rec=curs.fetchone()
        dic={}
        try:
            dic['Id']=int(rec[0])
            dic['CompanyId']=int(rec[1])
            dic['CompanyName']=rec[2]
            dic['CarName']=rec[3]
            dic['NoOfWheels']=int(rec[4])
            dic['EngineCapacity']=rec[5]
            dic['FuelType']=rec[6]
            dic['Price']=float(rec[7])
            dic['CarType']=rec[8]
        except:
            dic['message']='Not Found'
        
        return dic

api.add_resource(CarInfo,"/car/<modelName>")
app.run(debug=True)
