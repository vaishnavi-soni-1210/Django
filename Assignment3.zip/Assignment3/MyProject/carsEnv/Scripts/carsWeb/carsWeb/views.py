from distutils.log import error
from django.http import HttpResponse
from django.shortcuts import render
import pymysql
from .models import UserRegistration

def index(request):
    #return HttpResponse('django project running fine')
    return render(request,'index.html')

def newAccount(request):
    return render(request,'openAccount.html')

def registerUser(request):
    mess=None
    if request.method=="POST":
        try:
            fname=request.POST.get("firstName")
            lname=request.POST.get("lastName")
            email=request.POST.get("emailAddress")
            mob=request.POST.get("mobileNumber")
            #create object of model class
            obj=UserRegistration()
            mess=obj.registerUser(fname,lname,email,mob)
        except ValueError as err:
            mess=err
        
        return render(request,'openAccount.html',{'result':mess})

def showAllCars(request):
    obj=UserRegistration()
    data=obj.showAllCars()
    return render(request,'AllCars.html',{"list":data})
