from flask import Flask
from flask_restful import Resource,Api
import pymysql

app=Flask(__name__)
api=Api(app)

class CustomerInfo(Resource):
    def get(self,id):
        con=pymysql.connect(host='bme17yv2uewp4z5ou9c2-mysql.services.clever-cloud.com',user='upx7pvsovd5grndj',password='zFYKoGDMCiX3s5DZXAJY',database='bme17yv2uewp4z5ou9c2')
        curs=con.cursor()
        curs.execute("select * from Customers where Id=%d" %id) 
        rec=curs.fetchone()
        dic={}
        try:
            dic['Id']=int(rec[0])
            dic['FirstName']=rec[1]
            dic['LastName']=rec[2]
            dic['EmailAddress']=rec[3]
            dic['MobileNumber']=rec[4]
        except:
            dic['message']='Not Found'
        
        return dic

api.add_resource(CustomerInfo,"/customer/<id>")
app.run(debug=True)
